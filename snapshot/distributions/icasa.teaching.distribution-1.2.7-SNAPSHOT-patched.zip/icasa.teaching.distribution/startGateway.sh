sh ./chameleon.sh --interactive
