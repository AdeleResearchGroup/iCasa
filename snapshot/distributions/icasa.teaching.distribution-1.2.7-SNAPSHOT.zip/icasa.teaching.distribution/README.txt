iCasa teaching distribution
====================

This is a distribution of iCasa.
You can find more information about the execution platform including source code on the iCasa website (https://github.com/AdeleResearchGroup/iCasa).

iCasa  is licensed under Apache V2 license.


To launch the platform, execute startGateway.bat on Windows or startGateway.sh file on Unix systems depending on your operating system.


Use iCasa-Simulator
====================

Supported browsers:
- Firefox
- Chrome

Open a web browser on url http://localhost:9000/simulator to get home simulator screen.
